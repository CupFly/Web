class Animal {
    String name;
    String color;

    Animal(String name, String color) {
        this.name = name;
        this.color = color;
    }
}

class Dog extends Animal {
    Dog(String name, String color) {
        super(name, color);
    }

    String makeSound() {
        return "Hau! Jestem " + name + " i jestem " + color + ".";
    }
}

class Cat extends Animal {
    Cat(String name, String color) {
        super(name, color);
    }

    String makeSound() {
        return "Miał! Jestem " + name + " i jestem " + color + ".";
    }
}

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog("Wolny", "biały");
        Cat cat = new Cat("Spretka", "czarny");

        System.out.println(dog.makeSound());
        System.out.println(cat.makeSound());
    }
}