public class Main{
    public static void main(String[] args) {
        kwadrat Kwadrat = new kwadrat(2);

        System.out.println(Kwadrat.Pole());
        System.out.println(Kwadrat.Obwod());
    }
}