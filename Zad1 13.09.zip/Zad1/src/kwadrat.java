public class kwadrat {

    private int bok;

    public kwadrat(int bok) {
        this.bok = bok;
    }

    public kwadrat() {
    }

    public int getBok() {
        return bok;
    }

    public void setBok(int bok) {
        this.bok = bok;
    }

    public int Pole (){
        int bok = this.bok;
        return bok*bok;
    }

    public int Obwod () {
        int bok = this.bok;
        return bok * 4;
    }
}
