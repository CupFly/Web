public class Main {
    public static final int SLOW = 1;
    public static final int MEDIUM = 2;
    public static final int FAST = 3;

    private int predkosc;
    private boolean isOn;
    private double promien;
    private String kolor;

    public Main(int predkosc, boolean isOn, double promien, String kolor) {
        this.predkosc = predkosc;
        this.isOn = isOn;
        this.promien = promien;
        this.kolor = kolor;
    }

    public String informacje() {
        String status = isOn ? "włączony" : "wyłączony";
        return "Prędkość: " + predkosc + ", Stan: " + status + ", Promień: " + promien + ", Kolor: " + kolor;
    }

    public static void main(String[] args) {
        Main Wiatrak = new Main(FAST, true, 10.5, "Niebieski");
        System.out.println("Własny wiatrak: " + Wiatrak.informacje());
    }
}