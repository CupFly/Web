public class Main {
    public static final int SLOW = 1;
    public static final int MEDIUM = 2;
    public static final int FAST = 3;

    private int speed;
    private boolean isOn;
    private double radius;
    private String color;

    public Main(int speed, boolean isOn, double radius, String color) {
        this.speed = speed;
        this.isOn = isOn;
        this.radius = radius;
        this.color = color;
    }

    public String informacje() {
        String status = isOn ? "włączony" : "wyłączony";
        return "Prędkość: " + speed + ", Stan: " + status + ", Promień: " + radius + ", Kolor: " + color;
    }

    public static void main(String[] args) {
        Main customWiatrak = new Main(FAST, true, 10.5, "Niebieski");
        System.out.println("Własny wiatrak: " + customWiatrak.informacje());
    }
}