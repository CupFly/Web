public class Main {
    private String imie;
    private int wiek;
    private String miasto;
    private String panstwo;
    private double placa;

    public Main(String imie, int wiek, String miasto, String panstwo, double placa) {
        this.imie = imie;
        this.wiek = wiek;
        this.miasto = miasto;
        this.panstwo = panstwo;
        this.placa = placa;
    }

    @Override
    public String toString() {
        return "imie: " + imie + ", wiek: " + wiek + ", miasto: " + miasto + ", państwo: " + panstwo + ", placa: " + placa;
    }

    public static void main(String[] args) {
        Main obj = new Main("Łukasz", 18, "Gdańsk", "Polska", 0);
        System.out.println(obj);
    }
}
