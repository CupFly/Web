public class Punkt {
    private double x;
    private double y;

    public Punkt() {
        this.x = 0;
        this.y = 0;
    }

    public Punkt(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double odległość(double xInny, double yInny) {
        double dx = this.x - xInny;
        double dy = this.y - yInny;
        return Math.sqrt(dx * dx + dy * dy);
    }

    public double odległość(Punkt innyPunkt) {
        return odległość(innyPunkt.x, innyPunkt.y);
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
}