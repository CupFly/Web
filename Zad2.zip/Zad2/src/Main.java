public class Main{
    public static void main(String[] args) {
        Punkt punkt1 = new Punkt();
        Punkt punkt2 = new Punkt(3, 4);

        System.out.println(punkt1.odległość(punkt2));
    }
}