class A {
    void present(String phrase) {
        System.out.println(phrase);
    }
}

class B extends A {
    void present(String phrase) {
        super.present(phrase);
    }
}

class C extends B {
    void present(String phrase) {
        super.present(phrase);
    }
}

class D extends C {
    void present(String phrase) {
        super.present(phrase);
    }
}

class E extends D {
    void present(String phrase) {
        super.present(phrase);
    }
}

public class Main {
    public static void main(String[] args) {
        E e = new E();
        e.present("el Wolny cw");
    }
}
